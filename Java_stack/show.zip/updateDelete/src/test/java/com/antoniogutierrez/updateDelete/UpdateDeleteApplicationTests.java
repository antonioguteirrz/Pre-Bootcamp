package com.antoniogutierrez.updateDelete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateDeleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
